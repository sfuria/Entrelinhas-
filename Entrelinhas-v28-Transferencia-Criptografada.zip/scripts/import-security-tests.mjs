import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';
import vm from 'node:vm';
import {deflateRawSync} from 'node:zlib';
const root=path.resolve(import.meta.dirname,'..');
const src=fs.readFileSync(path.join(root,'app.js'),'utf8');
const start=src.indexOf('const EL_ZIP_MAX_ENTRIES=');
const end=src.indexOf('function dataMedia(',start);
assert(start>=0&&end>start);
const context=vm.createContext({Uint8Array,DataView,TextDecoder,Blob,DecompressionStream,Response,Error,URL,Map,Promise});
vm.runInContext(`const decoder=new TextDecoder();${src.slice(start,end)};globalThis.zipRead=zipRead`,context);
const zipRead=context.zipRead;
const u16=x=>[x&255,(x>>>8)&255],u32=x=>[x&255,(x>>>8)&255,(x>>>16)&255,(x>>>24)&255];
function zip(items){let offset=0;const local=[],central=[];for(const entry of items){const name=new TextEncoder().encode(entry.name),plain=new TextEncoder().encode(entry.data),method=entry.method??0,raw=method===8?deflateRawSync(plain):plain,expected=entry.expected??plain.length;
const l=Uint8Array.from([...u32(0x04034b50),...u16(20),...u16(0),...u16(method),...u16(0),...u16(0),...u32(0),...u32(raw.length),...u32(expected),...u16(name.length),...u16(0),...name,...raw]);
const c=Uint8Array.from([...u32(0x02014b50),...u16(20),...u16(20),...u16(0),...u16(method),...u16(0),...u16(0),...u32(0),...u32(raw.length),...u32(expected),...u16(name.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset),...name]);local.push(l);central.push(c);offset+=l.length;}
const csize=central.reduce((a,b)=>a+b.length,0);const end=Uint8Array.from([...u32(0x06054b50),...u16(0),...u16(0),...u16(items.length),...u16(items.length),...u32(csize),...u32(offset),...u16(0)]);return new Blob([...local,...central,end])}
let passed=0;
async function test(name,fn){await fn();console.log('PASS',name);passed++}
await test('ZIP armazenado válido',async()=>{const z=await zipRead(zip([{name:'word/document.xml',data:'<doc>Olá</doc>'}]));assert.equal(new TextDecoder().decode(await z.get('word/document.xml')()),'<doc>Olá</doc>')});
await test('ZIP compactado válido',async()=>{const z=await zipRead(zip([{name:'chapter.xhtml',data:'Texto literário com acentos',method:8}]));assert.equal(new TextDecoder().decode(await z.get('chapter.xhtml')()),'Texto literário com acentos')});
await test('Caminho atravessando diretórios bloqueado',async()=>{await assert.rejects(()=>zipRead(zip([{name:'../private.txt',data:'s'}])),/inseguro/)});
await test('Entradas duplicadas bloqueadas',async()=>{await assert.rejects(()=>zipRead(zip([{name:'dup',data:'a'},{name:'dup',data:'b'}])),/duplicado/)});
await test('Entrada maior que limite bloqueada antes de alocar',async()=>{await assert.rejects(()=>zipRead(zip([{name:'large',data:'a',expected:13*1024*1024}])),/excede o limite/)});
await test('ZIP declarando tamanho falso rejeitado após inflar',async()=>{const z=await zipRead(zip([{name:'bomb',data:'A'.repeat(120000),method:8,expected:10}]));await assert.rejects(()=>z.get('bomb')(),/excede o tamanho declarado/)});
await test('Nome local incompatível com central rejeitado',async()=>{const b=new Uint8Array(await zip([{name:'normal.txt',data:'a'}]).arrayBuffer());b[30]='X'.charCodeAt(0);await assert.rejects(()=>zipRead(new Blob([b])),/inconsistentes/)});
console.log(`APROVADO: ${passed} casos isolados de ZIP.`);
