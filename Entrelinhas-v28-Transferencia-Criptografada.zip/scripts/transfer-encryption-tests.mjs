import {readFileSync} from 'node:fs';
import {webcrypto} from 'node:crypto';
import vm from 'node:vm';
import assert from 'node:assert/strict';
const app=readFileSync(new URL('../app.js',import.meta.url),'utf8');
const start=app.indexOf('const EL_BACKUP_ITERATIONS=');
const end=app.indexOf('// Biblioteca Privada:',start);
assert.ok(start>=0&&end>start,'Funções de backup presentes');
const source=app.slice(start,end);
const responses=['senha-teste-longa-2026','senha-teste-longa-2026'];
const context=vm.createContext({
 crypto:webcrypto,TextEncoder,TextDecoder,Uint8Array,Promise,JSON,Array,Date,Math,
 atob,btoa,globalThis:null,
 data:{version:2,projects:[{id:'ficcao',title:'TÍTULO SECRETO'}],sessions:[],documents:[{id:'cap1',title:'CAPÍTULO CONFIDENCIAL',html:'<p>MANUSCRITO PRIVADO</p>'}],notes:[]},
 prompt:()=>responses.shift(),saved:true,storageQueue:Promise.resolve(),view:'main',elVaultLocked:false,
 saveDoc:()=>{},saveNotePage:()=>{},
});
context.globalThis=context;
vm.runInContext(source,context,{timeout:5000});
const encrypted=await vm.runInContext('elTransferEnvelope()',context,{timeout:5000});
assert.equal(encrypted.format,'entrelinhas-encrypted-backup');
assert.equal(encrypted.cipher,'AES-256-GCM');
const envelope=JSON.stringify(encrypted);
assert.ok(!envelope.includes('MANUSCRITO PRIVADO'));
assert.ok(!envelope.includes('CAPÍTULO CONFIDENCIAL'));
context.prompt=()=> 'senha-teste-longa-2026';
const decrypted=await vm.runInContext(`elRestoreProtected(${envelope})`,context,{timeout:5000});
assert.equal(decrypted.documents[0].html,'<p>MANUSCRITO PRIVADO</p>');
context.prompt=()=> 'senha-errada-teste';
await assert.rejects(vm.runInContext(`elRestoreProtected(${envelope})`,context,{timeout:5000}));
console.log('PASS Criptografia AES-GCM, nenhum manuscrito em claro, restauração e rejeição de senha inválida');
