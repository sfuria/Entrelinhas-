import fs from 'node:fs';
import assert from 'node:assert/strict';
import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const s=fs.readFileSync(path.join(root,'app.js'),'utf8');
const checks=[
 ['Colagem interceptada antes da inserção',/addEventListener\('paste',event=>\{[\s\S]*?event\.preventDefault\(\)/.test(s)],
 ['Arquivos arrastados impedidos',/addEventListener\('drop',event=>\{[\s\S]*?event\.preventDefault\(\)/.test(s)],
 ['Sanitização antes de inserir HTML colado',/const clean=html\?sanitize\(html\):''/.test(s)],
 ['Inserção simples usa texto literal',/execCommand\('insertText',false,text\|\|''\)/.test(s)],
 ['Apenas áreas editáveis gerenciadas',/closest\?\.\('#writingArea\[contenteditable/.test(s)],
 ['Imagens remotas bloqueadas pelo sanitizador',/Imagem externa ou muito grande removida por segurança/.test(s)],
 ['Links sem protocolos executáveis',/\['https:','http:'\]\.includes\(u\.protocol\)/.test(s)],
 ['Rejeição de elementos executáveis',/\['SCRIPT','STYLE','IFRAME','OBJECT','EMBED','SVG'/.test(s)],
 ['Sem parse duplo de HTML importado',!s.includes('id="clean-root"')],
 ['HTML colado limitado a 8 MB',s.includes("html.length>8*1024*1024")],
];
for(const [name,ok] of checks){console.log((ok?'PASS':'FAIL')+' '+name);assert.ok(ok,name)}
console.log('10 verificações de regressão estrutural aprovadas; não substituem testes XSS no navegador.');
